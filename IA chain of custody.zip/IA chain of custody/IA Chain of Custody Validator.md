

# IA Chain of Custody Validator

[TOC]

## Introduction

IA Chain of Custody Validator Schedules COC validation check for an IA application, which works only for EP4 or above.

## Extraction Process

### Get Started

To get started Click on `Start` 

![1533805813403](C:\Users\P3\AppData\Local\Temp\1533805813403.png)



### Configuration

![1533806689456](C:\Users\P3\AppData\Local\Temp\1533806689456.png)

> Input Screen

The Inputs required to schedule the COC validation check are captured here 

> `Application name` 

Give the Name of your application, this will be your application name in the end

>  `InfoArchive Username and Password`

Enter infoarchive Username and Password to browse the respective metadata file 

Then click on Browse `Metadata File`option to select the metadata file location which will then be added in the metadata file location  

Click on `Schedule` option to schedule the validate job

### Job Status

A pop up screen will be appeared on clicking the Schedule Option where we can schedule the job to our preference accordingly.

![1533809212638](C:\Users\P3\AppData\Local\Temp\1533809212638.png)

> **Click Schedule option to `schedule` the job**  



![1533886035200](IA Chain of Custody Validator.assets/1533886035200.png)



Users can even schedule it later feeding the `start date` and `end date`

An information stating the  Job reference id will be populated on clicking schedule option 



![1533809245151](C:\Users\P3\AppData\Local\Temp\1533809245151.png)



### Schedule Monitoring

User(s) can track the status of the job using the `Status Monitoring` or `Schedule Job Monitoring` modules from the Archon's launcher pad. Within the tool User(s) get a convenient option to check on the status of the scheduled jobs for the Chain of Custody Validator. This can be accessed using the option shown. 

![1533809558301](C:\Users\P3\AppData\Local\Temp\1533809558301.png)



## Output

Once Archon's background services complete processing your job, an email will be triggered.

![1533809934122](IA Chain of Custody Validator.assets/1533809934122.png)

> E-mail notification



