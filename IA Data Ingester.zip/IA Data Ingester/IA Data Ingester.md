# IA Data Ingester

[TOC]

## Introduction

Archon data ingester is a tool, which is used for ingesting extracted data into Info archive  of Table and sip based Info archive application as well as meta data for table based application

##Ingestion Process

## Getting Started





![1533888206219](C:\Users\P3\AppData\Local\Temp\1533888206219.png)

> Click on `Start` to Begin 



### Configuration



![1533892103338](C:\Users\P3\AppData\Local\Temp\1533892103338.png)

> The Inputs required to ingest data  are captured here 



`Ingest Category:`

Select the data type to be ingested which could be a table or meta data 

`Application Type:`

Select the type of application which the data belongs to.

`Application Name:`

Give a name of your choice to the application

`Schema Name:`

Enter the exact Schema name of the table in this space.

`InfoArchive details:`

Enter the Info archive user name and password to access the table that we wish to ingest 

`Data Directory Path:` 

Enter the data directory path where the table to be ingested is located



### Scheduling the job



Click on `Schedule` option to schedule the ingest job

A pop up screen will be appeared on clicking the Schedule Option where we can schedule the job to our preference accordingly.

![1533809212638](C:\Users\P3\AppData\Local\Temp\1533809212638.png)

> **Click Schedule option to `schedule` the job**  



![1533886035200](C:/Users/P3/Desktop/IA%20Chain%20of%20Custody%20Validator.assets/1533886035200.png)



Users can even schedule it later feeding the `start date` and `end date`

An information stating the  Job reference id will be populated on clicking schedule option

![1533893155526](C:\Users\P3\AppData\Local\Temp\1533893155526.png)



### Schedule Monitoring

User(s) can track the status of the job using the `Status Monitoring` or `Schedule Job Monitoring` modules from the Archon's launcher pad. Within the tool User(s) get a convenient option to check on the status of the scheduled jobs for the IA Data Ingester . This can be accessed using the option shown. 

![1533893671878](C:\Users\P3\AppData\Local\Temp\1533893671878.png)





## Output

Once Archon's background services complete processing your job, an email will be triggered.

![1533893336620](C:\Users\P3\AppData\Local\Temp\1533893336620.png)

> E-mail notification



